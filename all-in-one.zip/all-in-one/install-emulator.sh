#! /bin/bash


# 1. Install xposed
adb push xposed-zip /sdcard/
adb shell "cd /sdcard/xposed-zip && sh flash-script.sh"
adb install xposed-installer-3-1-1.apk

# 2. Install AimDroid-controller

adb install app-debug.apk

# 3. Install ape

adb shell mount -o rw,remount /system
adb push ape /system/bin
adb push ape.jar /sdcard/

adb push libart-compiler.so /system/lib
adb push libart.so /system/lib

adb shell chmod 644 /system/lib/libart.so
adb shell chown root:root /system/lib/libart.so

adb shell chmod 644 /system/lib/libart-compiler.so
adb shell chown root:root /system/lib/libart-compiler.so

adb reboot
