#! /bin/bash


# 1. Install xposed
adb push xposed-zip /sdcard/
adb shell "cd /sdcard/xposed-zip && sh flash-script.sh"
adb install xposed-installer-3-1-1.apk

# 2. Install AimDroid-controller

adb install app-debug.apk

# 3. Install ape

adb shell mount -o rw,remount /system
adb push ape /system/bin
adb push ape.jar /sdcard/

adb reboot
